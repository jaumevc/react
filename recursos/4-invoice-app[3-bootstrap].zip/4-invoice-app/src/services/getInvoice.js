import { invoice } from "../data/invoice"

export const getInvoice = () => {

    console.log(invoice)
    return invoice;
}