
let firstname = 'Pepe';
firstname = 'andres';

const lastname = 'Doe';
// lastname = 'Roe';
const condicion = true;

if (condicion) {
    const lastname = 'Ale';
    console.log(lastname)
}

console.log(`Hola mundo!!!! ${firstname} - ${lastname}`);