
export const UserDetails = ({user, id}) => (
    <div>
        que tal! {user.name} {user.lastName} con el id {id}
    </div>
);