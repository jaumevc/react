import { products } from "../data/products"

export const getProducts = () => {
    return products;
}