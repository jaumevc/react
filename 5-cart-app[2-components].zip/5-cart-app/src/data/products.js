export const products = [
    {
        id: 1,
        name: 'Teclado Mecanico RGB',
        description: 'Teclado Mecanico con luces RGB switches cherry red',
        price: 1000
    },
    {
        id: 2,
        name: 'Samsung Smart TV 55',
        description: 'Excelente tv LCD...',
        price: 3000
    },
    {
        id: 3,
        name: 'Audifono Bluetooth Sony',
        description: 'Audifono Bluetooth para smartphone',
        price: 770
    },
    {
        id: 4,
        name: 'Memoria Corsair 8GB DDR5',
        description: 'Memoria RAM optimizada para Juegos',
        price: 3700
    },
    {
        id: 5,
        name: 'Asus Nvidia RTX',
        description: 'Tarjeta Grafica para juegos en 4k',
        price: 5000
    },
    {
        id: 6,
        name: 'CPU Intel Core i5',
        description: 'Optimizada para tareas multicore',
        price: 4000
    },
]